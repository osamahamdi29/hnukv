<?php

    /*!
	 * POCKET v3.7
	 *
	 * http://www.droidoxy.com
	 * support@droidoxy.com
	 *
	 * Copyright 2020 DroidOXY ( http://www.droidoxy.com )
	 */
?>
<!--
Template : Pocket - Money Making Script
Author: DroidOXY
Website: http://www.droidoxy.com/
Contact: support@droidoxy.com
Support: http://www.droidoxy.com/support

Purchase Admin Panel from [CodyHub]: https://www.codyhub.com/item/pocket-admin/?ref=droidoxy

Purchase Web Version from [CodyHub]: https://www.codyhub.com/item/web-rewards-app-pocket/?ref=droidoxy
Purchase Android Version from [CodyHub]: https://www.codyhub.com/item/android-rewards-app-pocket/?ref=droidoxy
Purchase IOS Version from [CodyHub]: https://www.codyhub.com/item/ios-rewards-app-pocket/?ref=droidoxy

Purchase ADDONS from [DroidOXY]: https://www.droidoxy.com/products/

Purchase Android Version from [Codecanyon]: https://codecanyon.net/item/android-rewards-app-pocket/17413949?ref=droidoxy
Purchase IOS Version from [Codecanyon]: https://codecanyon.net/item/ios-rewards-app-pocket/24811671?ref=droidoxy

License: You must have a valid license purchased only from the above links in order to legally use this product.
-->
